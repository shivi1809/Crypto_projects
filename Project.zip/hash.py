# -*- coding: utf-8 -*-
"""
Created on Sat Dec  9 11:58:19 2017

@author: Shivi-Gupta
"""

""" Implementation of SHA256 and SHA512 using following libraries:
    1. Crypto
    2. hashlib
    3. Cryyptography
    """
# Reading a 6MB file
with open('file.txt') as f:
    read_data = f.read()
    f.closed
    
a = str.encode(read_data)
import timeit #to record elapsed time
  
""" Crypto Library"""
start_time = timeit.default_timer()
from Crypto.Hash import SHA256
hash_object = SHA256.new(a) #SHA256
hash_object.hexdigest()
elapsed1 = timeit.default_timer() - start_time
print("SHA256 using Crypto Library")
print(elapsed1)

start_time = timeit.default_timer()
from Crypto.Hash import SHA512  #SHA512
hash_object = SHA512.new(a)
hash_object.hexdigest()
elapsed1= timeit.default_timer() - start_time
print("SHA512 using Crypto Library")
print(elapsed1)

""" hashlib Library"""

start_time = timeit.default_timer()
import hashlib
hashlib.sha256(a).hexdigest()  #SHA256
elapsed1= timeit.default_timer() - start_time
print("SHA256 using hashlib Library")
print(elapsed1)
import timeit
start_time = timeit.default_timer()
hashlib.sha512(a).hexdigest()  #SHA512
elapsed1= timeit.default_timer() - start_time
print("SHA512 using hashlib Library")
print(elapsed1)

""" Cryptography Library """

from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
start_time = timeit.default_timer()
digest = hashes.Hash(hashes.SHA256(), backend=default_backend()) # SHA256
digest.update(a)
digest.finalize()
elapsed1= timeit.default_timer() - start_time
print("SHA256 using Cryptography Library")
print(elapsed1)
start_time = timeit.default_timer()
digest = hashes.Hash(hashes.SHA512(), backend=default_backend())  #SHA512
digest.update(a)
digest.finalize()
elapsed1= timeit.default_timer() - start_time
print("SHA512 using Cryptography Library")
print(elapsed1)