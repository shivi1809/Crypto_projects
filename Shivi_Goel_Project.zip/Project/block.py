# -*- coding: utf-8 -*-
"""
Created on Sat Dec  9 12:47:25 2017

@author: Shivi-Gupta
"""

"""
Implementing AES and TDES using following libraries:
    1. oscrypto
    2. Cryptography
    3. pycryptodome
"""
# Reading a 6MB file
with open('file.txt') as f:
    read_data = f.read()
    f.closed
    

a = str.encode(read_data)
import timeit

    
""" Using oscrypto Library"""

""" AES 256"""

from oscrypto import symmetric
import os
key = os.urandom(32)
iv = os.urandom(16)
start_time = timeit.default_timer()
(iv,CT) = symmetric.aes_cbc_pkcs7_encrypt(key,a,iv)
elapsed1 = timeit.default_timer() - start_time
print("Encrypting in AES256 using oscrypto library")
print(elapsed1)
start_time = timeit.default_timer()
Pt= symmetric.aes_cbc_pkcs7_decrypt(key,CT,iv)
elapsed1 = timeit.default_timer() - start_time
print("Decrypting in AES256 using oscrypto library")
print(elapsed1)

"""TDES keying option 3 """

start_time = timeit.default_timer()
key = os.urandom(24)
iv = os.urandom(8)
(iv,CT) = symmetric.tripledes_cbc_pkcs5_encrypt(key,a,iv)
elapsed1 = timeit.default_timer() - start_time
print("Encrypting in TDES,keying option 3 using oscrypto library")
print(elapsed1)
start_time = timeit.default_timer()
Pt= symmetric.tripledes_cbc_pkcs5_decrypt(key,CT,iv)
elapsed1 = timeit.default_timer() - start_time
print("Decrypting in TDES,keying option 3 using oscrypto library")
print(elapsed1)


"Cryptography Library"

""" TDES keying option 3"""

import os
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
backend = default_backend()
start_time = timeit.default_timer()
key = os.urandom(24)
iv = os.urandom(8)
cipher = Cipher(algorithms.TripleDES(key), modes.CBC(iv), backend=backend)
encryptor = cipher.encryptor()
ct = encryptor.update(a) + encryptor.finalize()
elapsed1= timeit.default_timer() - start_time
print("Encrypting in TDES,keying option 3 using Cryptography library")
print(elapsed1)

start_time = timeit.default_timer()
decryptor = cipher.decryptor()
decryptor.update(ct) + decryptor.finalize()
elapsed1= timeit.default_timer() - start_time
print("Decrypting in TDES,keying option 3 using Cryptography library")
print(elapsed1)

""" AES 256"""

import os
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding # have to include it externally
padder = padding.PKCS7(256).padder()
padded_data = padder.update(a)
from cryptography.hazmat.backends import default_backend
backend = default_backend()
start_time = timeit.default_timer()
key = os.urandom(32)
iv = os.urandom(16)
cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=backend)
encryptor = cipher.encryptor()
ct = encryptor.update(padded_data) + encryptor.finalize()
elapsed1= timeit.default_timer() - start_time
print("Encrypting in AES 256 using Cryptography library")
print(elapsed1)

start_time = timeit.default_timer()
decryptor = cipher.decryptor()
decryptor.update(ct) + decryptor.finalize()
elapsed1= timeit.default_timer() - start_time
print("Decrypting in AES 256 using Cryptography library")
print(elapsed1)

""" pycryptodome"""

""" AES 256"""

from Cryptodome.Cipher import AES
start_time = timeit.default_timer()
key = os.urandom(32)
cipher = AES.new(key, AES.MODE_EAX)
nonce = cipher.nonce
ciphertext, tag = cipher.encrypt_and_digest(a)
elapsed1= timeit.default_timer() - start_time
print("Encrypting in AES 256 using pycryptodome library")
print(elapsed1)
start_time = timeit.default_timer()
cipher = AES.new(key, AES.MODE_EAX, nonce=nonce)
plaintext = cipher.decrypt(ciphertext)
try:
    cipher.verify(tag)
except ValueError:
    print("Key incorrect or message corrupted")
elapsed1= timeit.default_timer() - start_time
print("Decrypting in AES 256 using pycryptodome library")
print(elapsed1)

""" TDES keying option 3"""

from Cryptodome.Cipher import DES3
from Cryptodome.Random import get_random_bytes

start_time = timeit.default_timer()
while True:
    try:
         key = DES3.adjust_key_parity(get_random_bytes(24))
         break
    except ValueError:
         pass

cipher = DES3.new(key, DES3.MODE_CBC)
msg = msg = cipher.encrypt(a)
elapsed1= timeit.default_timer() - start_time
print("Encrypting in TDES keying option 3 using pycryptodome library")
print(elapsed1)
start_time = timeit.default_timer()
cipher = DES3.new(key, DES3.MODE_CBC)
PT = cipher.decrypt(msg)
elapsed1= timeit.default_timer() - start_time
print("Decrypting in TDES keying option 3 using pycryptodome library")
print(elapsed1)
