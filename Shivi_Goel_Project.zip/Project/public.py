# -*- coding: utf-8 -*-
"""
Created on Sat Dec  9 16:28:16 2017

@author: Shivi-Gupta
"""

"""
Implementing RSA and ECDSA using following libraries:
    1. oscrypto
    2. Cryptography
    3. pycryptodome

"""

# Reading a 6MB file

with open('file.txt') as f:
    read_data = f.read()
    f.closed

a = str.encode(read_data)
import timeit


"""RSA using Cryptography library """

from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.asymmetric import rsa
private_key = rsa.generate_private_key(public_exponent=65537,key_size=2048,backend=default_backend())
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding
private_key = rsa.generate_private_key(public_exponent=65537,key_size=2048,backend=default_backend())
public_key = private_key.public_key()
start_time = timeit.default_timer()
for i in range(0,31654):
    
    ciphertext = public_key.encrypt(
    a[i*200:i*200+200],
    padding.OAEP(
    mgf=padding.MGF1(algorithm=hashes.SHA1()),
    algorithm=hashes.SHA1(),
    label=None
    )
    )
    
    plaintext = private_key.decrypt(
    ciphertext,
    padding.OAEP(
    mgf=padding.MGF1(algorithm=hashes.SHA1()),
    algorithm=hashes.SHA1(),
    label=None
    )
    )
elapsed2 = timeit.default_timer() - start_time
print("RSA using Cryptography Library")
print(elapsed2)



"""RSA using oscrypto """

from oscrypto import asymmetric
(pub,private) = asymmetric.generate_pair("rsa",2048)
start_time = timeit.default_timer()
for i in range(0,31654):
    
   CT = asymmetric.rsa_pkcs1v15_encrypt(pub,a[i*200:i*200+200])
   PT = asymmetric.rsa_pkcs1v15_decrypt(private,CT)
elapsed2 = timeit.default_timer() - start_time
print("RSA using oscrypto Library")
print(elapsed2)


""" RSA using pycryptodome"""

from Cryptodome.Cipher import PKCS1_OAEP
from Cryptodome.PublicKey import RSA
from Cryptodome import Random
random_generator = Random.new().read
keys = RSA.generate(2048, random_generator)
pubkey = keys.publickey()
privkey = keys.exportKey()
pubcipher = PKCS1_OAEP.new(pubkey) 
privcipher = PKCS1_OAEP.new(keys) 
privkeystr = keys.exportKey(format='PEM', passphrase=None, pkcs=1)
pubkeystr = keys.publickey().exportKey(format='PEM', passphrase=None, pkcs=1)

def encrypt_val(session_key, cipher = pubcipher):
    try:
        session_key = session_key.encode('utf8')
    except:
        pass
    ciphertext = cipher.encrypt(session_key)
    
    return ciphertext


def decrypt_val(ciphertext, cipher = privcipher):
    session_key = cipher.decrypt(ciphertext)
    try:
        session_key = session_key.decode('utf8')
    except:
        pass
    return session_key
start_time = timeit.default_timer()
for i in range(0,31654):
    CT= encrypt_val(a[i*200:i*200+200],pubcipher)
    PT = decrypt_val(CT,privcipher)
elapsed2 = timeit.default_timer() - start_time
print("RSA using pycryptodome Library")
print(elapsed2)   


""" ECDSA using oscrypto library"""

from oscrypto import asymmetric

(pub,private) = asymmetric.generate_pair("ec",None,"secp256r1")
start_time = timeit.default_timer()
CT = asymmetric.ecdsa_sign(private,a,"sha256")
asymmetric.ecdsa_verify(pub,CT,a,"sha256")
elapsed2 = timeit.default_timer() - start_time
print("ECDSA using oscrypto library")
print(elapsed2)

""" ECDSA using Cryptography library"""

from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
start_time = timeit.default_timer()
private_key = ec.generate_private_key(ec.SECP256R1(), default_backend())
signature = private_key.sign(a,ec.ECDSA(hashes.SHA256()))
public_key = private_key.public_key()
public_key.verify(signature, a, ec.ECDSA(hashes.SHA256()))
elapsed2 = timeit.default_timer() - start_time
print("ECDSA using Cryptography library")
print(elapsed2)

""" ecdsa using ecdsa library"""

import ecdsa
from ecdsa import SigningKey
start_time = timeit.default_timer()
sk = SigningKey.generate(curve=ecdsa.SECP256k1) 
vk = sk.get_verifying_key()
sig = sk.sign(a)
vk.verify(sig, a)
elapsed2 = timeit.default_timer() - start_time
print("ecdsa using ecdsa library")
print(elapsed2)



