# -*- coding: utf-8 -*-
"""
Created on Sat Dec  9 13:09:33 2017

@author: Shivi-Gupta
"""

"""
Implementing 
RC4 using libraries:
    1. oscrypto
    2. pycryptodome
    3. Cryptography
Salsa20 using libraries:
    1. pycryptodome
    2. pyNacl
    3. pycrypto
"""
# Reading a 6MB file
with open('file.txt') as f:
    read_data = f.read()
    f.closed

a = str.encode(read_data)

import timeit

                       # RC4

"""Using oscrypto Library """
start_time = timeit.default_timer()
from oscrypto import symmetric
import os
key = os.urandom(16)
CT = symmetric.rc4_encrypt(key,a)
elapsed1 = timeit.default_timer() - start_time
print("Encrypting in RC4 using oscrypto library")
print(elapsed1)
start_time = timeit.default_timer()
PT = symmetric.rc4_decrypt(key,CT)
elapsed1 = timeit.default_timer() - start_time
print("Decrypting in RC4 using oscrypto library")
print(elapsed1)


""" Using pycryptodome library"""
start_time = timeit.default_timer()
from Cryptodome.Cipher import ARC4
from Cryptodome.Hash import SHA
from Cryptodome.Random import get_random_bytes
key = b'Very long and confidential key'
nonce = get_random_bytes(16)
tempkey = SHA.new(key+nonce).digest()
cipher = ARC4.new(tempkey)
msg = cipher.encrypt(a)
elapsed1 = timeit.default_timer() - start_time
print("Encrypting in RC4 using pycryptodome library")
print(elapsed1)
start_time = timeit.default_timer()
cipher = ARC4.new(tempkey)
msg = cipher.decrypt(msg)
elapsed1 = timeit.default_timer() - start_time
print("Decrypting in RC4 using pycryptodome library")
print(elapsed1)


""" using cryptography library """
start_time = timeit.default_timer()
import os
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms
from cryptography.hazmat.backends import default_backend
backend = default_backend()
start_time = timeit.default_timer()
key = os.urandom(16)
algorithm = algorithms.ARC4(key)
cipher = Cipher(algorithm, mode=None, backend=default_backend())
encryptor = cipher.encryptor()
ct = encryptor.update(a)
elapsed1 = timeit.default_timer() - start_time
print("Encrypting in RC4 using Cryptography library")
print(elapsed1)
start_time = timeit.default_timer()
decryptor = cipher.decryptor()
decryptor.update(ct)
elapsed = timeit.default_timer() - start_time
print("Decrypting in RC4 using Cryptography library")
print(elapsed)

     
         # Salsa20  


"""using pycryptodome """
start_time = timeit.default_timer()
from Cryptodome.Cipher import Salsa20
import os
key = os.urandom(32)
cipher = Salsa20.new(key)
msg = cipher.nonce + cipher.encrypt(a)
elapsed1 = timeit.default_timer() - start_time
print("Encrypting in Salsa20 using pycryptodome library")
print(elapsed1)
start_time = timeit.default_timer()
msg_nonce = msg[:8]
ciphertext = msg[8:]
cipher = Salsa20.new(key, nonce=msg_nonce)
plaintext = cipher.decrypt(ciphertext)
elapsed1 = timeit.default_timer() - start_time
print("Decrypting in Salsa20 using pycryptodome library")
print(elapsed1)


"""using PyNacl"""

start_time = timeit.default_timer()
import nacl.secret
import nacl.utils
key = nacl.utils.random(nacl.secret.SecretBox.KEY_SIZE)
box = nacl.secret.SecretBox(key)
nonce = nacl.utils.random(nacl.secret.SecretBox.NONCE_SIZE)
encrypted = box.encrypt(a, nonce)
elapsed1 = timeit.default_timer() - start_time
print("Encrypting in Salsa20 using pyNacl library")
print(elapsed1)
start_time = timeit.default_timer()
plaintext = box.decrypt(encrypted)
elapsed1 = timeit.default_timer() - start_time
print("Decrypting in Salsa20 using pyNacl library")
print(elapsed1)

"""Using pycrypto library """
start_time = timeit.default_timer()
from Crypto.Cipher import Salsa20
import os
key = os.urandom(32)
cipher = Salsa20.new(key)
msg = cipher.nonce + cipher.encrypt(a)
elapsed1 = timeit.default_timer() - start_time
print("Encrypting in Salsa20 using pycrypto library")
print(elapsed1)
start_time = timeit.default_timer()
msg_nonce = msg[:8]
ciphertext = msg[8:]
cipher = Salsa20.new(key, nonce=msg_nonce)
plaintext = cipher.decrypt(ciphertext)
elapsed1 = timeit.default_timer() - start_time
print("Decrypting in Salsa20 using pycrypto library")
print(elapsed1)
