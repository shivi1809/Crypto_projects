This project is designed on Windows 7 OS using Anaconda and python 3.6

Please install following before executing the program files:

pip install oscrypto

pip install cryptography

pip install pycryptodome

pip install pynacl

pip install pyCrypto

pip install ecdsa

Make sure you are using python 3.6 or latest.

For Encryption/Decryption, a 6MB file, file.txt has been used. 

For analysis purpose, each algorithm was run 100 times and total execution time has been 
recorded and attached in analysis_data.xlsx file